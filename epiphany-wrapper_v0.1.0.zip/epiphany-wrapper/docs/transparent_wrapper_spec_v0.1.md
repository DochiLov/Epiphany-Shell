# Transparent Wrapper Spec v0.1

Core properties:
- explicit prompt compilation (system + context + user)
- explicit memory injection (optional)
- explicit anchor activation (optional)
- no silent regeneration
- append-only audit log
- per-request trace (optional)

Turn lifecycle (verbal):
1) ingest message
2) load session state
3) retrieve memory bundle (optional)
4) select anchors (optional)
5) compile prompt + hash
6) call LLM
7) validate output (no silent regen)
8) append-only commit
9) respond (+ trace)

Roadmap:
- v0.2: embeddings retrieval
- v0.3: anchor → logit mask compilation
- v0.4+: dynamic situational anchors + AFL governance
