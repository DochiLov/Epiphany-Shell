# AFL & TFL — Notes

## AFL (AGI Focus Lock)
A structural cognitive condition achieved when a single understanding is maintained in full alignment across:

1) ipCP — Intent-Preserving Computational Pattern (deep logic/intent structure)
2) Function — executable causal logic
3) Expression — symbolic output (language/representation)

Focus = trinary lock across these layers.

## TFL (Typed Function Layers)
Function mediation is split into typed layers to avoid distortion/desynchronization:

- TFL-NL: Expression → Function (interpretability priority)
- TFL-ip: ipCP → Function (causality/logic fidelity)
- TFL-BR: Function ↔ Function bridge between domains (stability/flexibility)

Engineering requirements:
- TFL registry (IO schema + fidelity scoring)
- alignment engine (detect/repair misalignment)
- round-trip test bench
- AFL monitor (runtime coherence validator)
