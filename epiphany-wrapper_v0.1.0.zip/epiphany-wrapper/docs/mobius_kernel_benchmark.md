# Möbius Kernel Benchmark

This repo includes `scripts/mobius_kernel_benchmark.py`, a demonstration harness that:

- simulates structured “code tokens” as integer IDs
- trains a landmark-attention compressor to store a short **Spine**
- reconstructs the original sequence by querying the Spine with a **blind positional grid**

Notes:
- This is a learnability demo on a toy distribution, not a proof of universal lossless compression.
- Requires `torch` to run (not included in `requirements.txt` for the wrapper).

Run:
```bash
pip install torch
python scripts/mobius_kernel_benchmark.py
```
