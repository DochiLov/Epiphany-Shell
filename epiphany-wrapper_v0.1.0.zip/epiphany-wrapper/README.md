# Epiphany Wrapper (Transparent Runtime) — v0.1.0

A minimal, inspectable FastAPI wrapper that sits **in front of** an LLM endpoint and makes:

- prompt compilation
- memory injection
- anchor activation
- validation
- logging

**explicit**.

This repo is deliberately **basics-first**: memory and anchors are OFF by default so you can verify the pipeline before adding complexity.

---

## Quickstart

### 1) Install

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
```

### 2) Set your API key

```bash
export OPENAI_API_KEY="..."
```

### 3) Run

```bash
uvicorn app.main:app --host 127.0.0.1 --port 8080 --reload
```

### 4) Smoke test

```bash
curl -s http://127.0.0.1:8080/health | python -m json.tool
```

```bash
curl -s http://127.0.0.1:8080/talk \
  -H "Content-Type: application/json" \
  -d '{"session_id":"demo","message":"Explain how attention works in transformers.","mode":"sasha_architect","trace":true}' \
  | python -m json.tool
```

---

## Configuration

- `config/settings.yaml` — feature toggles + model parameters
- `config/anchors.json` — anchor registry (v0.1: simple rule triggers)

### Enable anchors

Edit `config/settings.yaml`:

```yaml
anchors:
  enabled: true
```

### Enable memory

Edit `config/settings.yaml`:

```yaml
memory:
  enabled: true
```

Add memory records to `data/memory/memory.jsonl` (one JSON object per line), e.g.:

```json
{"id":"US0.C1","type":"semantic","ts":"2026-02-14T00:00:00+00:00","tags":["continuity"],"text":"US0.C1 Continuity: sustaining flame; thread binding; drift tolerance."}
```

---

## Transparency tools

### Trace (per-request)
Send `"trace": true` in `/talk` to receive:
- active anchors
- memory bundle used
- prompt hash
- model params
- validator flags

### Audit log (append-only)
Every `/talk` call appends an event to `data/audit/YYYY-MM-DD.jsonl`.

---

## Roadmap (suggested)

- v0.2: embedding retrieval (pgvector) + stronger validator
- v0.3: anchors compiled to logit masks (logit processors)
- v0.4+: dynamic situational anchors + AFL governance + multi-model routing
