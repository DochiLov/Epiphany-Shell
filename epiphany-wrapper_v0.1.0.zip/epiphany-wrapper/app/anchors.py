from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import List, Tuple


@dataclass
class Anchor:
    id: str
    label: str
    description: str
    keywords_any: List[str]
    modes_any: List[str]
    prompt_directives: List[str]


class AnchorRegistry:
    def __init__(self, path: Path):
        self.path = path
        self.anchors: List[Anchor] = []
        self.load()

    def load(self) -> None:
        data = json.loads(self.path.read_text(encoding="utf-8"))
        anchors = []
        for a in data.get("anchors", []):
            anchors.append(
                Anchor(
                    id=a["id"],
                    label=a.get("label", ""),
                    description=a.get("description", ""),
                    keywords_any=[k.lower() for k in a.get("triggers", {}).get("keywords_any", [])],
                    modes_any=a.get("triggers", {}).get("modes_any", []),
                    prompt_directives=a.get("effects", {}).get("prompt_directives", []),
                )
            )
        self.anchors = anchors

    def select(self, message: str, mode: str, max_active: int = 5) -> List[Anchor]:
        msg = (message or "").lower()
        active: List[Tuple[Anchor, int]] = []
        for a in self.anchors:
            mode_ok = (not a.modes_any) or (mode in a.modes_any)
            if not mode_ok:
                continue
            hits = sum(1 for kw in a.keywords_any if kw and kw in msg)
            if hits > 0:
                active.append((a, hits))
        active.sort(key=lambda x: x[1], reverse=True)
        return [a for a, _ in active[:max_active]]

    @staticmethod
    def directives_block(active: List[Anchor]) -> List[str]:
        directives: List[str] = []
        for a in active:
            directives.append(f"[{a.id} - {a.label}]")
            directives.extend([f"- {d}" for d in a.prompt_directives])
            directives.append("")
        return directives
