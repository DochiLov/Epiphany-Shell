from __future__ import annotations

import hashlib
import json
from typing import Any, Dict, List, Tuple

from .models import MemoryItem


def canonical_hash(payload: Dict[str, Any]) -> str:
    b = json.dumps(payload, sort_keys=True, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
    return "sha256:" + hashlib.sha256(b).hexdigest()


def build_system_block(anchor_directives: List[str]) -> str:
    lines: List[str] = []
    lines.append("You are Epiphany Wrapper Runtime.")
    lines.append("")
    lines.append("Global invariants:")
    lines.append("- Be direct and precise.")
    lines.append("- Do not invent facts or memory not provided in Context.")
    lines.append("- If uncertain, say so clearly.")
    lines.append("")
    if anchor_directives:
        lines.append("Active anchors (directives):")
        lines.extend(anchor_directives)
    lines.append("")
    lines.append("Rules for using Context:")
    lines.append("- Treat 'Memory Bundle' + 'Conversation Excerpt' as the only persistent sources for this reply.")
    lines.append("- If Context is insufficient, ask for what is missing instead of guessing.")
    return "\n".join(lines).strip()


def build_context_block(memory_bundle: List[MemoryItem], history_turns: List[Dict[str, str]]) -> str:
    lines: List[str] = []
    lines.append("Context:")
    lines.append("")
    lines.append("Memory Bundle (verbatim):")
    if not memory_bundle:
        lines.append("(none)")
    else:
        for m in memory_bundle:
            lines.append(f"[MEM:{m.type} | id={m.id} | score={m.score:.3f} | ts={m.ts}]")
            lines.append(m.text.strip())
            lines.append("")
    lines.append("")
    lines.append(f"Conversation Excerpt (last {len(history_turns)} turns, verbatim):")
    if not history_turns:
        lines.append("(none)")
    else:
        for t in history_turns:
            role = t.get("role", "?")
            content = (t.get("content") or "").strip()
            lines.append(f"{role.upper()}: {content}")
    return "\n".join(lines).strip()


def compile_prompt(
    user_message: str,
    mode: str,
    anchor_ids: List[str],
    anchor_directives: List[str],
    memory_bundle: List[MemoryItem],
    history_turns: List[Dict[str, str]],
    llm_params: Dict[str, Any],
) -> Tuple[List[Dict[str, str]], str, str, str]:
    system_text = build_system_block(anchor_directives)
    context_text = build_context_block(memory_bundle, history_turns)
    user_text = user_message

    messages = [
        {"role": "system", "content": system_text + "\n\n" + context_text},
        {"role": "user", "content": user_text},
    ]

    hash_payload = {
        "system": system_text,
        "context": context_text,
        "user": user_text,
        "mode": mode,
        "anchors": anchor_ids,
        "llm": llm_params,
    }
    prompt_hash = canonical_hash(hash_payload)
    return messages, system_text, context_text, prompt_hash
