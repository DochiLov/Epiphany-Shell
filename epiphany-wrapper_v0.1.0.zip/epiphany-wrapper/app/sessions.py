from __future__ import annotations

import json
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, List, Literal

Role = Literal["system", "user", "assistant"]


def utc_now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


@dataclass
class Turn:
    role: Role
    content: str
    ts: str = field(default_factory=utc_now_iso)


@dataclass
class SessionState:
    session_id: str
    mode: str = "sasha_architect"
    turns: List[Turn] = field(default_factory=list)
    meta: Dict[str, str] = field(default_factory=dict)

    def to_json(self) -> Dict:
        return {
            "session_id": self.session_id,
            "mode": self.mode,
            "turns": [t.__dict__ for t in self.turns],
            "meta": self.meta,
        }

    @staticmethod
    def from_json(data: Dict) -> "SessionState":
        turns = [Turn(**t) for t in data.get("turns", [])]
        return SessionState(
            session_id=data["session_id"],
            mode=data.get("mode", "sasha_architect"),
            turns=turns,
            meta=data.get("meta", {}),
        )


class SessionStore:
    def __init__(self, sessions_dir: Path):
        self.sessions_dir = sessions_dir
        self.sessions_dir.mkdir(parents=True, exist_ok=True)

    def _path(self, session_id: str) -> Path:
        safe = "".join(c for c in session_id if c.isalnum() or c in ("-", "_"))[:128] or "default"
        return self.sessions_dir / f"{safe}.json"

    def load(self, session_id: str) -> SessionState:
        p = self._path(session_id)
        if not p.exists():
            return SessionState(session_id=session_id)
        return SessionState.from_json(json.loads(p.read_text(encoding="utf-8")))

    def save(self, state: SessionState) -> None:
        self._path(state.session_id).write_text(json.dumps(state.to_json(), indent=2), encoding="utf-8")

    def append(self, state: SessionState, role: Role, content: str) -> None:
        state.turns.append(Turn(role=role, content=content))
