from __future__ import annotations

import os
from pathlib import Path
from typing import Any, Dict

import yaml


def project_root() -> Path:
    return Path(__file__).resolve().parents[1]


def load_settings(path: str | None = None) -> Dict[str, Any]:
    root = project_root()
    settings_path = root / (path or "config/settings.yaml")
    data = yaml.safe_load(settings_path.read_text(encoding="utf-8"))

    # Minimal env overrides (v0.1)
    if os.getenv("EPI_MODEL"):
        data.setdefault("llm", {})["model"] = os.environ["EPI_MODEL"]
    if os.getenv("EPI_BASE_URL"):
        data.setdefault("llm", {})["base_url"] = os.environ["EPI_BASE_URL"]

    if os.getenv("EPI_MEMORY_ENABLED") is not None:
        data.setdefault("memory", {})["enabled"] = os.getenv("EPI_MEMORY_ENABLED").lower() in ("1","true","yes")
    if os.getenv("EPI_ANCHORS_ENABLED") is not None:
        data.setdefault("anchors", {})["enabled"] = os.getenv("EPI_ANCHORS_ENABLED").lower() in ("1","true","yes")

    return data
