from __future__ import annotations

import os
from typing import Any, Dict, List, Tuple

import requests


class LLMError(RuntimeError):
    pass


def call_openai_chat_completions(
    *,
    base_url: str,
    model: str,
    messages: List[Dict[str, str]],
    temperature: float,
    top_p: float,
    max_output_tokens: int,
    timeout_seconds: int,
) -> Tuple[str, Dict[str, Any]]:
    api_key = os.getenv("OPENAI_API_KEY")
    if not api_key:
        raise LLMError("Missing OPENAI_API_KEY environment variable.")

    url = base_url.rstrip("/") + "/chat/completions"
    headers = {"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"}
    payload = {
        "model": model,
        "messages": messages,
        "temperature": float(temperature),
        "top_p": float(top_p),
        "max_tokens": int(max_output_tokens),
    }

    try:
        resp = requests.post(url, headers=headers, json=payload, timeout=timeout_seconds)
    except requests.RequestException as e:
        raise LLMError(f"HTTP error calling LLM: {e}") from e

    if resp.status_code >= 400:
        raise LLMError(f"LLM returned HTTP {resp.status_code}: {resp.text}")

    data = resp.json()
    try:
        text = data["choices"][0]["message"]["content"]
    except Exception:
        raise LLMError(f"Unexpected LLM response format: {data}")

    meta = {"id": data.get("id"), "created": data.get("created"), "usage": data.get("usage", {}), "model": data.get("model", model)}
    return text, meta
