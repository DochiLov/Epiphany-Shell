from __future__ import annotations

import json
import math
import re
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Tuple


def _utc_now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def _parse_iso(ts: str) -> Optional[datetime]:
    try:
        return datetime.fromisoformat(ts.replace("Z", "+00:00"))
    except Exception:
        return None


def _tokenize(text: str) -> List[str]:
    return re.findall(r"[A-Za-z0-9_\.]+", (text or "").lower())


@dataclass
class MemoryRecord:
    id: str
    type: str
    text: str
    ts: str
    tags: List[str]

    def to_json(self) -> Dict[str, Any]:
        return {"id": self.id, "type": self.type, "text": self.text, "ts": self.ts, "tags": self.tags}


class MemoryStore:
    def __init__(self, path: Path):
        self.path = path
        self.path.parent.mkdir(parents=True, exist_ok=True)
        if not self.path.exists():
            self.path.write_text("", encoding="utf-8")

    def add(self, rec: MemoryRecord) -> None:
        with self.path.open("a", encoding="utf-8") as f:
            f.write(json.dumps(rec.to_json(), ensure_ascii=False) + "\n")

    def _iter(self) -> Iterable[MemoryRecord]:
        for line in self.path.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if not line:
                continue
            try:
                d = json.loads(line)
                yield MemoryRecord(
                    id=d["id"],
                    type=d.get("type", "semantic"),
                    text=d.get("text", ""),
                    ts=d.get("ts", _utc_now_iso()),
                    tags=list(d.get("tags", [])),
                )
            except Exception:
                continue

    def retrieve_tags(self, query: str, top_k: int = 6, min_score: float = 0.0) -> List[Tuple[MemoryRecord, float]]:
        q_tokens = set(_tokenize(query))
        now = datetime.now(timezone.utc)

        scored: List[Tuple[MemoryRecord, float]] = []
        for rec in self._iter():
            rec_tokens = set(_tokenize(rec.text)) | set(t.lower() for t in rec.tags)
            overlap = len(q_tokens & rec_tokens)

            dt = _parse_iso(rec.ts)
            if dt is None:
                recency = 0.0
            else:
                age_days = max(0.0, (now - dt).total_seconds() / 86400.0)
                recency = math.exp(-age_days / 14.0)

            score = overlap + 0.25 * recency
            if score >= min_score:
                scored.append((rec, score))

        scored.sort(key=lambda x: x[1], reverse=True)
        return scored[:top_k]
