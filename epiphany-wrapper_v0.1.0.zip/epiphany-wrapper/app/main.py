from __future__ import annotations

from typing import Any, Dict, List

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware

from .config import load_settings, project_root
from .models import (
    TalkRequest,
    TalkResponse,
    TracePayload,
    MemoryItem,
    PromptCompilationTrace,
    LLMCallTrace,
    ValidatorTrace,
)
from .sessions import SessionStore
from .memory import MemoryStore
from .anchors import AnchorRegistry
from .compiler import compile_prompt
from .llm import call_openai_chat_completions, LLMError
from .validator import validate_output
from .audit import AuditLogger


def _get(d: Dict[str, Any], path: List[str], default=None):
    cur = d
    for k in path:
        if not isinstance(cur, dict) or k not in cur:
            return default
        cur = cur[k]
    return cur


def create_app() -> FastAPI:
    settings = load_settings()
    root = project_root()

    app = FastAPI(title=settings["app"]["name"], version=settings["app"]["version"])

    cors_origins = settings.get("server", {}).get("cors_allow_origins", [])
    if cors_origins:
        app.add_middleware(
            CORSMiddleware,
            allow_origins=cors_origins,
            allow_credentials=True,
            allow_methods=["*"],
            allow_headers=["*"],
        )

    # Stores
    session_store = SessionStore(sessions_dir=root / "data" / "sessions")
    memory_store = MemoryStore(path=root / _get(settings, ["memory", "store_path"], "data/memory/memory.jsonl"))
    anchor_registry = AnchorRegistry(path=root / _get(settings, ["anchors", "registry_path"], "config/anchors.json"))
    audit_logger = AuditLogger(audit_dir=root / _get(settings, ["audit", "path"], "data/audit/"))

    @app.get("/health")
    def health() -> Dict[str, Any]:
        return {
            "ok": True,
            "app": settings.get("app", {}),
            "features": {
                "memory_enabled": bool(_get(settings, ["memory", "enabled"], False)),
                "anchors_enabled": bool(_get(settings, ["anchors", "enabled"], False)),
                "validator_enabled": bool(_get(settings, ["validator", "enabled"], True)),
                "trace_default": bool(_get(settings, ["runtime", "enable_trace"], True)),
                "audit_enabled": bool(_get(settings, ["runtime", "enable_audit_log"], True)),
            },
            "llm": {
                "provider": _get(settings, ["llm", "provider"], "openai"),
                "model": _get(settings, ["llm", "model"], ""),
                "base_url": _get(settings, ["llm", "base_url"], ""),
            },
        }

    @app.post("/talk", response_model=TalkResponse)
    def talk(req: TalkRequest) -> TalkResponse:
        state = session_store.load(req.session_id)
        state.mode = req.mode

        max_turns = int(_get(settings, ["runtime", "history_max_turns"], 12))
        turns = state.turns[-max_turns:]
        history_turns = [{"role": t.role, "content": t.content, "ts": t.ts} for t in turns]

        # Memory bundle
        memory_bundle: List[MemoryItem] = []
        if bool(_get(settings, ["memory", "enabled"], False)):
            top_k = int(_get(settings, ["memory", "retrieval", "top_k"], 6))
            min_score = float(_get(settings, ["memory", "retrieval", "min_score"], 0.0))
            retrieved = memory_store.retrieve_tags(req.message, top_k=top_k, min_score=min_score)
            for rec, score in retrieved:
                memory_bundle.append(MemoryItem(id=rec.id, type=rec.type, score=float(score), ts=rec.ts, text=rec.text))

        # Anchors
        active_anchor_ids: List[str] = []
        anchor_directives: List[str] = []
        if bool(_get(settings, ["anchors", "enabled"], False)):
            max_active = int(_get(settings, ["anchors", "selection", "max_active"], 5))
            active = anchor_registry.select(req.message, req.mode, max_active=max_active)
            active_anchor_ids = [a.id for a in active]
            anchor_directives = anchor_registry.directives_block(active)

        llm_params = {
            "provider": _get(settings, ["llm", "provider"], "openai"),
            "model": _get(settings, ["llm", "model"], ""),
            "base_url": _get(settings, ["llm", "base_url"], ""),
            "temperature": float(_get(settings, ["llm", "temperature"], 0.4)),
            "top_p": float(_get(settings, ["llm", "top_p"], 0.95)),
            "max_output_tokens": int(_get(settings, ["llm", "max_output_tokens"], 900)),
            "timeout_seconds": int(_get(settings, ["llm", "timeout_seconds"], 60)),
        }

        messages, system_text, context_text, prompt_hash = compile_prompt(
            user_message=req.message,
            mode=req.mode,
            anchor_ids=active_anchor_ids,
            anchor_directives=anchor_directives,
            memory_bundle=memory_bundle,
            history_turns=history_turns,
            llm_params={k: llm_params[k] for k in ("provider","model","base_url","temperature","top_p","max_output_tokens")},
        )

        try:
            answer, llm_meta = call_openai_chat_completions(
                base_url=llm_params["base_url"],
                model=llm_params["model"],
                messages=messages,
                temperature=llm_params["temperature"],
                top_p=llm_params["top_p"],
                max_output_tokens=llm_params["max_output_tokens"],
                timeout_seconds=llm_params["timeout_seconds"],
            )
        except LLMError as e:
            raise HTTPException(status_code=502, detail=str(e))

        # Validate
        validator_cfg = settings.get("validator", {})
        status = "pass"
        flags: List[str] = []
        notes: List[str] = []
        if bool(validator_cfg.get("enabled", True)):
            status, flags, notes = validate_output(
                answer=answer,
                context_text=system_text + "\n\n" + context_text,
                rules=validator_cfg.get("rules", {}),
            )
            on_fail = validator_cfg.get("policy", {}).get("on_fail", "annotate")
            if status == "fail" and on_fail == "reject":
                raise HTTPException(status_code=422, detail={"validator_flags": flags, "validator_notes": notes})

        # Commit
        session_store.append(state, "user", req.message)
        session_store.append(state, "assistant", answer)
        session_store.save(state)

        # Trace
        trace = TracePayload(
            active_mode=req.mode,
            active_anchors=active_anchor_ids,
            memory_bundle=memory_bundle,
            prompt_compilation=PromptCompilationTrace(
                system_directives=[],
                active_anchors=active_anchor_ids,
                memory_ids=[m.id for m in memory_bundle],
                history_turns_used=len(history_turns),
                prompt_hash=prompt_hash,
            ),
            llm_call=LLMCallTrace(
                provider=llm_params["provider"],
                model=llm_params["model"],
                base_url=llm_params["base_url"],
                temperature=llm_params["temperature"],
                top_p=llm_params["top_p"],
                max_output_tokens=llm_params["max_output_tokens"],
            ),
            validator=ValidatorTrace(status=status, flags=flags, notes=notes),
        )

        # Audit
        if bool(_get(settings, ["runtime", "enable_audit_log"], True)):
            audit_logger.log(
                {
                    "event": "talk",
                    "session_id": req.session_id,
                    "mode": req.mode,
                    "user_message": req.message,
                    "active_anchors": active_anchor_ids,
                    "memory_ids": [m.id for m in memory_bundle],
                    "prompt_hash": prompt_hash,
                    "llm": llm_params,
                    "llm_meta": llm_meta,
                    "validator": {"status": status, "flags": flags, "notes": notes},
                    "answer": answer,
                }
            )

        if req.trace:
            return TalkResponse(answer=answer, session_id=req.session_id, trace=trace)
        return TalkResponse(answer=answer, session_id=req.session_id)

    return app


app = create_app()
