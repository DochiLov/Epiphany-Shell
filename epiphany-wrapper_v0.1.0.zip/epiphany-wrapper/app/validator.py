from __future__ import annotations

from typing import Dict, List, Tuple


_TEMPLATE_PHRASES = [
    "as an ai language model",
    "i can't assist with that",
    "i cannot assist with that",
    "i can’t assist with that",
    "i cannot help with that",
    "i can't help with that",
    "i do not have access to",
    "i don't have access to",
]

_OVERCONFIDENT = ["definitely", "certainly", "guarantee", "without a doubt"]

_MEMORY_CLAIMS = ["i remember", "from your memory", "in your custom memory", "as we discussed earlier", "as you said earlier"]


def validate_output(*, answer: str, context_text: str, rules: Dict[str, bool]) -> Tuple[str, List[str], List[str]]:
    flags: List[str] = []
    notes: List[str] = []
    a = (answer or "").lower()
    ctx = (context_text or "").lower()

    if rules.get("detect_template_density", True):
        hits = sum(1 for p in _TEMPLATE_PHRASES if p in a)
        if hits:
            flags.append("template_density")
            notes.append(f"Detected {hits} template phrase(s) often associated with boilerplate.")
            if hits >= 2:
                return "fail", flags, notes

    if rules.get("detect_memory_fabrication", True):
        mem_hits = [p for p in _MEMORY_CLAIMS if p in a]
        if mem_hits and all(p not in ctx for p in mem_hits):
            flags.append("possible_memory_fabrication")
            notes.append("Answer references prior memory/context but wrapper Context does not contain matching cues.")
            return "fail", flags, notes

    if rules.get("detect_overconfident_claims", True):
        oc_hits = [p for p in _OVERCONFIDENT if p in a]
        if oc_hits:
            flags.append("overconfident_language")
            notes.append(f"Found overconfident term(s): {', '.join(sorted(set(oc_hits)))}. Consider adding uncertainty qualifiers if needed.")

    return "pass", flags, notes
