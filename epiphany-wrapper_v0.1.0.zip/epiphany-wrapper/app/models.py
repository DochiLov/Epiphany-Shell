from __future__ import annotations

from typing import Any, Dict, List, Literal, Optional

from pydantic import BaseModel, Field


Mode = Literal["sasha_architect", "normal_user", "batch_task"]


class TalkRequest(BaseModel):
    session_id: str = Field(..., description="Client-provided session identifier")
    message: str = Field(..., description="User message text")
    mode: Mode = Field("sasha_architect", description="Conversation mode")
    trace: bool = Field(False, description="Return debug trace payload")


class MemoryItem(BaseModel):
    id: str
    type: Literal["semantic", "episodic", "project", "anchor"]
    score: float
    ts: str
    text: str


class PromptCompilationTrace(BaseModel):
    system_directives: List[str] = []
    active_anchors: List[str] = []
    memory_ids: List[str] = []
    history_turns_used: int = 0
    prompt_hash: str = ""


class LLMCallTrace(BaseModel):
    provider: str
    model: str
    base_url: str
    temperature: float
    top_p: float
    max_output_tokens: int


class ValidatorTrace(BaseModel):
    status: Literal["pass", "fail"] = "pass"
    flags: List[str] = []
    notes: List[str] = []


class TracePayload(BaseModel):
    active_mode: Mode
    active_anchors: List[str] = []
    memory_bundle: List[MemoryItem] = []
    prompt_compilation: PromptCompilationTrace
    llm_call: LLMCallTrace
    validator: ValidatorTrace


class TalkResponse(BaseModel):
    answer: str
    session_id: str
    trace: Optional[TracePayload] = None


def to_dict(model: BaseModel) -> Dict[str, Any]:
    if hasattr(model, "model_dump"):
        return model.model_dump()
    return model.dict()
