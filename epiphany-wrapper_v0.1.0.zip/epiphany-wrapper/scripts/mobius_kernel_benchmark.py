import torch
import torch.nn as nn
import torch.nn.functional as F
import math

# --- 1. Infrastructure: Embeddings & Positional Encoding ---
class PositionalEncoding(nn.Module):
    def __init__(self, d_model, max_len=5000):
        super().__init__()
        pe = torch.zeros(max_len, d_model)
        position = torch.arange(0, max_len, dtype=torch.float).unsqueeze(1)
        div_term = torch.exp(torch.arange(0, d_model, 2).float() * (-math.log(10000.0) / d_model))
        pe[:, 0::2] = torch.sin(position * div_term)
        pe[:, 1::2] = torch.cos(position * div_term)
        self.register_buffer('pe', pe.unsqueeze(0))

    def forward(self, x):
        # x: [B, T, D]
        return x + self.pe[:, :x.size(1)]

# --- 2. The Core: Möbius Block (Landmark Attention) ---
class MobiusAttention(nn.Module):
    def __init__(self, d_model, k_spine, n_heads):
        super().__init__()
        assert d_model % n_heads == 0
        self.d_model = d_model
        self.k_spine = k_spine
        self.n_heads = n_heads
        self.d_head = d_model // n_heads

        # Shared Weights (The "Twist")
        self.Wq = nn.Linear(d_model, d_model)
        self.Wk = nn.Linear(d_model, d_model)
        self.Wv = nn.Linear(d_model, d_model)

        # Landmark Queries (The "Compressor")
        self.q_landmarks = nn.Parameter(torch.randn(n_heads, k_spine, self.d_head))

    def _split_heads(self, X):
        B, T, D = X.shape
        return X.view(B, T, self.n_heads, self.d_head).transpose(1, 2).contiguous()

    def _merge_heads(self, Xh):
        B, H, T, dh = Xh.shape
        return Xh.transpose(1, 2).contiguous().view(B, T, H * dh)

    def compress(self, X):
        B, T, D = X.shape
        H, K, dh = self.n_heads, self.k_spine, self.d_head

        Kx = self._split_heads(self.Wk(X))
        Vx = self._split_heads(self.Wv(X))
        Q = self.q_landmarks.unsqueeze(0).expand(B, H, K, dh)

        scale = dh ** -0.5
        attn = torch.softmax((Q @ Kx.transpose(-1, -2)) * scale, dim=-1)
        S = self._merge_heads(attn @ Vx).view(B, K, D)
        return S

    def expand(self, Query, S):
        B, T, D = Query.shape
        H, K, dh = self.n_heads, self.k_spine, self.d_head

        Qx = self._split_heads(self.Wq(Query)) # Query the spine
        Ks = self._split_heads(self.Wk(S))     # Spine acts as Key
        Vs = self._split_heads(self.Wv(S))     # Spine acts as Value

        scale = dh ** -0.5
        attn = torch.softmax((Qx @ Ks.transpose(-1, -2)) * scale, dim=-1)
        X_hat = self._merge_heads(attn @ Vs)
        return X_hat

# --- 3. The Full System: Möbius Auto-Associator ---
class MobiusNLP(nn.Module):
    def __init__(self, vocab_size, d_model, k_spine, n_heads):
        super().__init__()
        self.embedding = nn.Embedding(vocab_size, d_model)
        self.pos_encoder = PositionalEncoding(d_model)
        self.mobius = MobiusAttention(d_model, k_spine, n_heads)

        # Output Head: Project back to Vocab
        self.to_vocab = nn.Linear(d_model, vocab_size)

    def forward(self, token_ids):
        # 1. Embed & Position
        x = self.embedding(token_ids) * math.sqrt(self.mobius.d_model)
        x = self.pos_encoder(x)

        # 2. Compress -> Spine
        spine = self.mobius.compress(x)

        # 3. Blind Expand (Using Fixed Grid)
        B, T, D = x.shape
        blind_grid = self.pos_encoder(torch.zeros(B, T, D, device=x.device))
        x_hat = self.mobius.expand(blind_grid, spine)

        # 4. Project to Logits
        logits = self.to_vocab(x_hat)
        return logits, spine

# --- 4. The Benchmark Loop ---
def generate_fake_kernel_code(batch_size, seq_len, vocab_size):
    """Simulates structured code using random integers."""
    return torch.randint(0, vocab_size, (batch_size, seq_len))

def map_tokens(tokens, vocab_map=None):
    if vocab_map is None:
        return str(tokens.tolist())
    return " ".join(vocab_map.get(int(t), f"tok{int(t)}") for t in tokens.tolist())

def run_benchmark():
    print("--- 1. LOADING KERNEL SIMULATION ---")

    # Specs
    VOCAB = 1000 # Size of code vocabulary
    DIM = 128    # Vector dimension
    Heads = 4
    CTX = 100    # Sequence Length (100 tokens of code)
    SPINE = 10   # Compression to 10 tokens (10:1 Ratio)

    print(f"Context: {CTX} tokens -> Spine: {SPINE} tokens")
    print(f"Compression Ratio: {CTX/SPINE}:1")

    model = MobiusNLP(VOCAB, DIM, SPINE, Heads)
    optimizer = torch.optim.AdamW(model.parameters(), lr=0.001)
    criterion = nn.CrossEntropyLoss()

    # Simulate a batch of code
    data = generate_fake_kernel_code(16, CTX, VOCAB) # Batch of 16 snippets

    print("\n--- 2. TRAINING (The Learning Phase) ---")
    print("Iter | Loss     | Accuracy (Token Match)")

    for i in range(501):
        optimizer.zero_grad()
        logits, _ = model(data)

        # Reshape for Loss: [B*T, Vocab]
        loss = criterion(logits.view(-1, VOCAB), data.view(-1))
        loss.backward()
        optimizer.step()

        if i % 100 == 0:
            preds = logits.argmax(dim=-1)
            acc = (preds == data).float().mean().item()
            print(f"{i:4d} | {loss.item():.4f}   | {acc*100:.1f}%")

    print("\n--- 3. VALIDATION (New snippet) ---")
    test_code = generate_fake_kernel_code(1, CTX, VOCAB)

    with torch.no_grad():
        logits, spine = model(test_code)
        reconstructed = logits.argmax(dim=-1)

    print(f"Spine Tensor Size: {spine.shape}")

    # Optional: map to pseudo-code words
    VOCAB_MAP = {
        0: 'int', 1: 'void', 2: 'return', 3: 'x', 4: 'y', 5: 'if', 6: 'else', 7: 'for',
        8: 'while', 9: 'struct', 10: '{', 11: '}', 12: '(', 13: ')', 14: ';', 15: '=',
    }

    print("\n--- VISUAL COMPARISON (First 20 Tokens) ---")
    print("ORIGINAL:", map_tokens(test_code[0, :20], VOCAB_MAP))
    print("MOBIUS  :", map_tokens(reconstructed[0, :20], VOCAB_MAP))

    match = (test_code == reconstructed).float().mean().item()
    print(f"\nFinal Reconstruction Accuracy: {match*100:.1f}%")

    if match > 0.95:
        print(">> VERDICT: HIGH-FIDELITY RECONSTRUCTION (demo success)")
    else:
        print(">> VERDICT: OPTIMIZATION NEEDED (increase DIM or SPINE)")

if __name__ == "__main__":
    run_benchmark()
