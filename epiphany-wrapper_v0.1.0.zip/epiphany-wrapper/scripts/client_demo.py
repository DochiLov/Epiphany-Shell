import json
import sys
import requests

BASE = "http://127.0.0.1:8080"

def main():
    session_id = sys.argv[1] if len(sys.argv) > 1 else "demo"
    msg = " ".join(sys.argv[2:]) if len(sys.argv) > 2 else "Explain the wrapper trace payload."
    payload = {"session_id": session_id, "message": msg, "mode": "sasha_architect", "trace": True}
    r = requests.post(BASE + "/talk", json=payload, timeout=60)
    r.raise_for_status()
    print(json.dumps(r.json(), indent=2))

if __name__ == "__main__":
    main()
